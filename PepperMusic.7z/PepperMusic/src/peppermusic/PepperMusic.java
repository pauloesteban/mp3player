/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package peppermusic;

/**
 *
 * @author orlando
 */
public class PepperMusic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        PepperMusicGUI form = new PepperMusicGUI();
        form.setVisible(true);
      /*Configuracion form2 = new Configuracion();
        form2.setVisible(true);*/
      // jf_Reproduccion form3 = new jf_Reproduccion();
        //form3.setVisible(true);
    }
    
}
